import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";

import CourtDetailPage from "./pages/CourtDetailPage";
import CourtsPage from "@/pages/CourtsPage";

import LoginPage from "@/pages/LoginPage";
import ProtectedRoute from "./components/ProtectedRoute";
import RegisterPage from "@/pages/RegisterPage";

import CourtProposalsAdminPage from "@/pages/CourtProposalsAdminPage";
import CourtReportPage from "@/pages/CourtReportPage";
import MyReportsPage from "@/pages/MyReportsPage";
import ReportDetailPage from "@/pages/ReportDetailPage";

import MunicipalityDashboardPage from "@/pages/MunicipalityDashboardPage";
import MunicipalityReportsPage from "@/pages/MunicipalityReportsDetailPage";
import MunicipalityDetailPage from "@/pages/MunicipalityDetailPage";
import MunicipalityCourtsPage from "@/pages/MunicipalityCourtsPage";
import MunicipalityCourtEditPage from "@/pages/MunicipalityCourtEditPage";

import EventsPage from "@/pages/EventsPage";
import EventDetailPage from "@/pages/EventDetailPage";
import EventCreatePage from "@/pages/EventCreatePage";
import EventEditPage from "@/pages/EventEditPage";
import EventCalendarPage from "@/pages/EventCalendarPage";

import ClubsPage from "@/pages/ClubsPage";
import ClubDetailPage from "@/pages/ClubDetailPage";
import ClubEditPage from "@/pages/ClubEditPage";

import TeamDetailPage from "@/pages/TeamDetailPage";
import TeamEditPage from "@/pages/TeamEditPage";
import TeamCreatePage from "@/pages/TeamCreatePage";

import LeaguesPage from "@/pages/LeaguesPage";
import LeagueDetailPage from "@/pages/LeagueDetailPage";

import GameEditPage from "@/pages/GameEditPage";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Startseite */}
        <Route path="/" element={<Navigate to="/courts" replace />} />

        {/* Authentifizierung */}
        <Route path="/login" element={<LoginPage />} />

        <Route path="/register" element={<RegisterPage />} />

        {/* Courts */}
        <Route path="/courts" element={<CourtsPage />} />

        <Route path="/courts/:courtId" element={<CourtDetailPage />} />

        {/* Vereine */}
        <Route path="/clubs" element={<ClubsPage />} />

        <Route path="/clubs/:clubId" element={<ClubDetailPage />} />

        {/* Mannschaften */}
        <Route
          path="/clubs/:clubId/teams/:teamId"
          element={<TeamDetailPage />}
        />

        {/* Ligen */}
        <Route path="/leagues" element={<LeaguesPage />} />

        <Route path="/leagues/:leagueId" element={<LeagueDetailPage />} />

        {/* Geschützte Bereiche */}
        <Route element={<ProtectedRoute />}>
          {/* Court-Verwaltung */}
          <Route
            path="/admin/court-proposals"
            element={<CourtProposalsAdminPage />}
          />

          <Route path="/courts/:courtId/report" element={<CourtReportPage />} />

          {/* Kommunalverwaltung */}
          <Route
            path="/municipality/dashboard"
            element={<MunicipalityDashboardPage />}
          />

          <Route
            path="/municipality/reports"
            element={<MunicipalityReportsPage />}
          />

          <Route
            path="/municipality/reports/:reportId"
            element={<MunicipalityDetailPage />}
          />

          <Route
            path="/municipality/courts"
            element={<MunicipalityCourtsPage />}
          />

          <Route
            path="/municipality/courts/:courtId/edit"
            element={<MunicipalityCourtEditPage />}
          />

          {/* Events */}
          <Route path="/events" element={<EventsPage />} />

          <Route path="/events/calendar" element={<EventCalendarPage />} />

          <Route path="/events/create" element={<EventCreatePage />} />

          <Route path="/events/:eventId/edit" element={<EventEditPage />} />

          <Route path="/events/:eventId" element={<EventDetailPage />} />

          {/* Vereinsverwaltung */}
          <Route path="/clubs/:clubId/edit" element={<ClubEditPage />} />

          {/* Mannschaftsverwaltung */}
          <Route
            path="/clubs/:clubId/teams/create"
            element={<TeamCreatePage />}
          />

          <Route
            path="/clubs/:clubId/teams/:teamId/edit"
            element={<TeamEditPage />}
          />

          {/* Spielverwaltung */}
          <Route
            path="/leagues/:leagueId/games/create"
            element={<GameEditPage />}
          />

          <Route
            path="/leagues/:leagueId/games/:gameId/edit"
            element={<GameEditPage />}
          />
        </Route>

        {/* Benutzerbereich */}
        <Route path="/profile/reports" element={<MyReportsPage />} />

        <Route path="/reports/:reportId" element={<ReportDetailPage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
