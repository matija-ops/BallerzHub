import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/lib/supabase";
import type { Tables } from "@/types/supabase.types";

type Club = Tables<"clubs">;
type Team = Tables<"teams">;

function RegisterPage() {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [bio, setBio] = useState("");
  const [basketballPosition, setBasketballPosition] = useState("");
  const [clubId, setClubId] = useState("");
  const [teamId, setTeamId] = useState("");

  const [clubs, setClubs] = useState<Club[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);

  const [isLoadingClubs, setIsLoadingClubs] = useState(true);
  const [isLoadingTeams, setIsLoadingTeams] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const [error, setError] = useState<string | null>(null);
  const [hasClub, setHasClub] = useState<boolean | null>(null);

  useEffect(() => {
    const loadClubs = async () => {
      const { data, error: clubsError } = await supabase
        .from("clubs")
        .select("*")
        .order("name");

      if (clubsError) {
        setError(clubsError.message);
      } else {
        setClubs(data);
      }

      setIsLoadingClubs(false);
    };

    loadClubs();
  }, []);

  useEffect(() => {
    const loadTeams = async () => {
      if (!clubId) {
        setTeams([]);
        setTeamId("");
        return;
      }

      setIsLoadingTeams(true);
      setTeamId("");

      const { data, error: teamsError } = await supabase
        .from("teams")
        .select("*")
        .eq("club_id", clubId)
        .order("name");

      if (teamsError) {
        setError(teamsError.message);
        setTeams([]);
      } else {
        setTeams(data);
      }

      setIsLoadingTeams(false);
    };

    loadTeams();
  }, [clubId]);

  const handleRegister = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    setIsLoading(true);
    setError(null);

    if (hasClub === null) {
      setError("Bitte gib an, ob du einem Verein angehörst.");
      setIsLoading(false);
      return;
    }

    if (hasClub && (!clubId || !teamId)) {
      setError("Bitte wähle einen Verein und eine Mannschaft aus.");
      setIsLoading(false);
      return;
    }

    const { data: authData, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {},
    });

    console.log(authData, signUpError);

    if (signUpError) {
      setError(signUpError.message);
      setIsLoading(false);
      return;
    }

    if (!authData.user) {
      setError("Der Benutzer konnte nicht erstellt werden.");
      setIsLoading(false);
      return;
    }

    const { error: profileError } = await supabase.from("profiles").insert({
      id: authData.user.id,
      username,
      display_name: displayName,
      avatar_url: avatarUrl || "",
      bio,
      basketball_position: basketballPosition,
      club_id: clubId || null,
      team_id: teamId || null,
    });

    if (profileError) {
      setError(profileError.message);
      setIsLoading(false);
      return;
    }

    navigate("/courts", { replace: true });
  };

  return (
    <main className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Account erstellen</CardTitle>
          <CardDescription>Erstelle dein Basketball-Profil.</CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleRegister} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">E-Mail</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="E-Mail-Adresse"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Passwort</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                placeholder="Passwort"
                required
                minLength={6}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="username">Benutzername</Label>
              <Input
                id="username"
                value={username}
                onChange={(event) => setUsername(event.target.value)}
                placeholder="@deinname"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="displayName">Anzeigename</Label>
              <Input
                id="displayName"
                value={displayName}
                onChange={(event) => setDisplayName(event.target.value)}
                placeholder="Dein Name"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="avatarUrl">Avatar-URL</Label>
              <Input
                id="avatarUrl"
                type="url"
                value={avatarUrl}
                onChange={(event) => setAvatarUrl(event.target.value)}
                placeholder="https://..."
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="position">Position</Label>
              <Select
                value={basketballPosition}
                onValueChange={setBasketballPosition}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Position auswählen" />
                </SelectTrigger>

                <SelectContent>
                  <SelectItem value="Point Guard">Point Guard</SelectItem>
                  <SelectItem value="Shooting Guard">Shooting Guard</SelectItem>
                  <SelectItem value="Small Forward">Small Forward</SelectItem>
                  <SelectItem value="Power Forward">Power Forward</SelectItem>
                  <SelectItem value="Center">Center</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Gehörst du einem Verein an?</Label>

              <Select
                value={hasClub === null ? "" : hasClub ? "yes" : "no"}
                onValueChange={(value) => {
                  const belongsToClub = value === "yes";

                  setHasClub(belongsToClub);

                  if (!belongsToClub) {
                    setClubId("");
                    setTeamId("");
                    setTeams([]);
                  }
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Bitte auswählen" />
                </SelectTrigger>

                <SelectContent>
                  <SelectItem value="yes">Ja</SelectItem>
                  <SelectItem value="no">Nein</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {hasClub && (
              <div className="space-y-2">
                <Label>Verein</Label>

                <Select value={clubId} onValueChange={setClubId}>
                  <SelectTrigger>
                    <SelectValue
                      placeholder={
                        isLoadingClubs
                          ? "Vereine werden geladen ..."
                          : "Verein auswählen"
                      }
                    />
                  </SelectTrigger>

                  <SelectContent>
                    {clubs.map((club) => (
                      <SelectItem key={club.id} value={club.id}>
                        {club.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="space-y-2">
              <Label>Mannschaft</Label>

              <Select
                value={teamId}
                onValueChange={setTeamId}
                disabled={!hasClub || !clubId || isLoadingTeams}
              >
                <SelectTrigger>
                  <SelectValue
                    placeholder={
                      !hasClub
                        ? "Nicht erforderlich"
                        : !clubId
                          ? "Zuerst Verein auswählen"
                          : isLoadingTeams
                            ? "Mannschaften werden geladen ..."
                            : "Mannschaft auswählen"
                    }
                  />
                </SelectTrigger>

                {hasClub && clubId && (
                  <SelectContent>
                    {teams.map((team) => (
                      <SelectItem key={team.id} value={team.id}>
                        {team.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                )}
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="bio">Über mich</Label>
              <Textarea
                id="bio"
                value={bio}
                onChange={(event) => setBio(event.target.value)}
                placeholder="Erzähl etwas über dich ..."
                required
              />
            </div>

            {error && <p className="text-sm text-destructive">{error}</p>}

            <Button
              type="submit"
              className="w-full"
              disabled={isLoading || isLoadingClubs || isLoadingTeams}
            >
              {isLoading ? "Account wird erstellt …" : "Registrieren"}
            </Button>

            <p className="text-center text-sm text-muted-foreground">
              Bereits registriert?{" "}
              <Link
                to="/login"
                className="font-medium text-foreground underline"
              >
                Einloggen
              </Link>
            </p>
          </form>
        </CardContent>
      </Card>
    </main>
  );
}

export default RegisterPage;
