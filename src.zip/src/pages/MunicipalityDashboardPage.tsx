import { useEffect, useMemo, useState } from "react";

import { supabase } from "@/lib/supabase";
import type { Tables } from "@/types/supabase.types";

import {
  getStatusLabel,
  isActiveReportStatus,
} from "@/constants/report-status";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

type Municipality = Tables<"municipalities">;
type CourtReport = Tables<"court_reports">;
type Court = Tables<"courts">;

type ReportWithCourt = CourtReport & {
  court: Pick<Court, "id" | "name"> | null;
};

function MunicipalityDashboardPage() {
  const [municipality, setMunicipality] = useState<Municipality | null>(null);
  const [reports, setReports] = useState<ReportWithCourt[]>([]);

  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadDashboard = async () => {
      setIsLoading(true);
      setError(null);

      try {
        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser();

        if (userError) {
          throw userError;
        }

        if (!user) {
          throw new Error("Du bist nicht eingeloggt.");
        }

        const { data: municipalityUser, error: municipalityUserError } =
          await supabase
            .from("municipality_users")
            .select("municipality_id")
            .eq("user_id", user.id)
            .maybeSingle();

        if (municipalityUserError) {
          throw municipalityUserError;
        }

        if (!municipalityUser) {
          throw new Error("Du bist keiner Kommune als Benutzer zugeordnet.");
        }

        const { data: municipalityData, error: municipalityError } =
          await supabase
            .from("municipalities")
            .select("*")
            .eq("id", municipalityUser.municipality_id)
            .single();

        if (municipalityError) {
          throw municipalityError;
        }

        setMunicipality(municipalityData);

        const { data: reportData, error: reportError } = await supabase
          .from("court_reports")
          .select(
            `
              *,
              court:courts!court_reports_court_id_fkey (
                id,
                name
              )
            `
          )
          .eq("municipality_id", municipalityUser.municipality_id)
          .order("created_at", { ascending: false });

        if (reportError) {
          throw reportError;
        }

        setReports(reportData ?? []);
      } catch (loadError) {
        console.error(
          "Kommunen-Dashboard konnte nicht geladen werden:",
          loadError
        );

        setError(
          loadError instanceof Error
            ? loadError.message
            : "Kommunen-Dashboard konnte nicht geladen werden."
        );
      } finally {
        setIsLoading(false);
      }
    };

    loadDashboard();
  }, []);

  const stats = useMemo(() => {
    return {
      active: reports.filter((report) => isActiveReportStatus(report.status))
        .length,

      neu: reports.filter(
        (report) => report.status.trim().toLowerCase() === "neu"
      ).length,

      inProgress: reports.filter(
        (report) => report.status.trim().toLowerCase() === "in progress"
      ).length,

      resolved: reports.filter(
        (report) => report.status.trim().toLowerCase() === "resolved"
      ).length,
    };
  }, [reports]);

  if (isLoading) {
    return (
      <main className="container mx-auto p-6">
        <p className="text-muted-foreground">
          Kommunen-Dashboard wird geladen...
        </p>
      </main>
    );
  }

  if (error) {
    return (
      <main className="container mx-auto p-6">
        <p className="text-destructive">{error}</p>
      </main>
    );
  }

  if (!municipality) {
    return (
      <main className="container mx-auto p-6">
        <p className="text-muted-foreground">Keine Kommune gefunden.</p>
      </main>
    );
  }

  return (
    <main className="container mx-auto p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Kommunen-Dashboard</h1>

        <p className="mt-2 text-muted-foreground">{municipality.name}</p>
      </div>

      <section className="mb-8">
        <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">Active</CardTitle>
            </CardHeader>

            <CardContent>
              <p className="text-3xl font-bold">{stats.active}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">Neu</CardTitle>
            </CardHeader>

            <CardContent>
              <p className="text-3xl font-bold">{stats.neu}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">In Progress</CardTitle>
            </CardHeader>

            <CardContent>
              <p className="text-3xl font-bold">{stats.inProgress}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">Resolved</CardTitle>
            </CardHeader>

            <CardContent>
              <p className="text-3xl font-bold">{stats.resolved}</p>
            </CardContent>
          </Card>
        </div>
      </section>
      <section>
        <div className="mb-4">
          <h2 className="text-xl font-semibold">Meldungen</h2>

          <p className="text-sm text-muted-foreground">
            Eingegangene Meldungen deiner Kommune
          </p>
        </div>

        {reports.length === 0 ? (
          <Card>
            <CardContent className="p-6">
              <p className="text-muted-foreground">
                Für diese Kommune liegen keine Meldungen vor.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {reports.map((report) => (
              <Card key={report.id}>
                <CardContent className="p-5">
                  <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                    <div className="min-w-0 space-y-2">
                      <div>
                        <p className="font-semibold">
                          {report.court?.name ?? "Unbekannter Court"}
                        </p>

                        <p className="text-sm text-muted-foreground">
                          {report.category}
                        </p>
                      </div>

                      <p className="text-sm leading-relaxed">
                        {report.description}
                      </p>

                      <div className="space-y-1 text-sm text-muted-foreground">
                        <p>
                          Meldungs-ID:{" "}
                          <span className="font-mono">{report.id}</span>
                        </p>

                        <p>
                          Gemeldet am:{" "}
                          {report.created_at
                            ? new Date(report.created_at).toLocaleDateString(
                                "de-DE"
                              )
                            : "Kein Datum"}
                        </p>

                        <p>
                          Aktualisiert am:{" "}
                          {report.updated_at
                            ? new Date(report.updated_at).toLocaleDateString(
                                "de-DE"
                              )
                            : "Kein Datum"}
                        </p>
                      </div>
                    </div>

                    <div className="shrink-0">
                      <Badge>{getStatusLabel(report.status)}</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}

export default MunicipalityDashboardPage;
