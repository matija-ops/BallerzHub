import { useEffect, useState, type FormEvent } from "react";
import { ArrowLeft, Save } from "lucide-react";
import { Link, useNavigate, useParams } from "react-router-dom";

import type { Tables, TablesInsert } from "@/lib/supabase";
import { supabase } from "@/lib/supabase";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type Club = Tables<"clubs">;
type League = Tables<"leagues">;

function TeamCreatePage() {
  const { clubId } = useParams<{ clubId: string }>();
  const navigate = useNavigate();

  const [club, setClub] = useState<Club | null>(null);
  const [leagues, setLeagues] = useState<League[]>([]);

  const [name, setName] = useState("");
  const [ageGroup, setAgeGroup] = useState("");
  const [leagueId, setLeagueId] = useState("");

  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  const [error, setError] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);

  useEffect(() => {
    if (!clubId) {
      setError("Kein Verein angegeben.");
      setIsLoading(false);
      return;
    }

    let isMounted = true;

    async function fetchData() {
      setIsLoading(true);
      setError(null);

      const [clubResult, leaguesResult] = await Promise.all([
        supabase.from("clubs").select("*").eq("id", clubId).single(),

        supabase.from("leagues").select("*").order("name", { ascending: true }),
      ]);

      if (!isMounted) {
        return;
      }

      if (clubResult.error) {
        console.error("Fehler beim Laden des Vereins:", clubResult.error);

        setError("Der Verein konnte nicht geladen werden.");
        setIsLoading(false);
        return;
      }

      if (leaguesResult.error) {
        console.error("Fehler beim Laden der Ligen:", leaguesResult.error);

        setError("Die Ligen konnten nicht geladen werden.");
        setIsLoading(false);
        return;
      }

      setClub(clubResult.data);
      setLeagues(leaguesResult.data ?? []);
      setIsLoading(false);
    }

    void fetchData();

    return () => {
      isMounted = false;
    };
  }, [clubId]);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!clubId) {
      setSaveError("Kein Verein angegeben.");
      return;
    }

    if (!name.trim()) {
      setSaveError("Bitte gib einen Mannschaftsnamen ein.");
      return;
    }

    if (!ageGroup.trim()) {
      setSaveError("Bitte gib eine Altersklasse ein.");
      return;
    }

    if (!leagueId) {
      setSaveError("Bitte wähle eine Liga aus.");
      return;
    }

    setIsSaving(true);
    setSaveError(null);

    const insert: TablesInsert<"teams"> = {
      club_id: clubId,
      name: name.trim(),
      age_group: ageGroup.trim(),
      league_id: leagueId,
    };

    const { data, error: supabaseError } = await supabase
      .from("teams")
      .insert(insert)
      .select("*")
      .single();

    if (supabaseError) {
      console.error("Fehler beim Erstellen der Mannschaft:", supabaseError);

      setSaveError(
        `Die Mannschaft konnte nicht erstellt werden: ${supabaseError.message}`
      );

      setIsSaving(false);
      return;
    }

    setIsSaving(false);

    navigate(`/clubs/${clubId}/teams/${data.id}`);
  }

  if (isLoading) {
    return (
      <main className="container mx-auto px-4 py-6">
        <Card className="max-w-2xl">
          <CardHeader>
            <Skeleton className="h-7 w-64" />
          </CardHeader>

          <CardContent className="space-y-6">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </CardContent>
        </Card>
      </main>
    );
  }

  if (error || !club) {
    return (
      <main className="container mx-auto px-4 py-6">
        <Card className="max-w-2xl">
          <CardContent className="py-6">
            <p className="text-sm text-destructive">
              {error ?? "Der Verein konnte nicht gefunden werden."}
            </p>

            <Button asChild variant="outline" className="mt-4">
              <Link to="/clubs">
                <ArrowLeft />
                Zurück zu den Vereinen
              </Link>
            </Button>
          </CardContent>
        </Card>
      </main>
    );
  }

  return (
    <main className="container mx-auto px-4 py-6">
      <div className="mb-6">
        <Button asChild variant="ghost">
          <Link to={`/clubs/${club.id}`}>
            <ArrowLeft />
            Zurück zum Verein
          </Link>
        </Button>
      </div>

      <Card className="max-w-2xl">
        <CardHeader>
          <CardTitle>Mannschaft hinzufügen</CardTitle>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label>Verein</Label>

              <Input value={club.name} disabled aria-label="Verein" />
            </div>

            <div className="space-y-2">
              <Label htmlFor="teamName">Mannschaftsname</Label>

              <Input
                id="teamName"
                value={name}
                onChange={(event) => setName(event.target.value)}
                placeholder="z. B. Testteam Damen"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="ageGroup">Altersklasse</Label>

              <Input
                id="ageGroup"
                value={ageGroup}
                onChange={(event) => setAgeGroup(event.target.value)}
                placeholder="z. B. U16m oder Herren"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="league">Liga</Label>

              <Select value={leagueId} onValueChange={setLeagueId}>
                <SelectTrigger id="league" className="w-full">
                  <SelectValue placeholder="Liga auswählen" />
                </SelectTrigger>

                <SelectContent>
                  {leagues.map((league) => (
                    <SelectItem key={league.id} value={league.id}>
                      {league.name}
                      {league.season ? ` · ${league.season}` : ""}
                      {league.division ? ` · ${league.division}` : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {saveError && (
              <div
                role="alert"
                className="rounded-md border border-destructive/50 bg-destructive/10 p-3 text-sm text-destructive"
              >
                {saveError}
              </div>
            )}

            <div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
              <Button asChild variant="outline">
                <Link to={`/clubs/${club.id}`}>Abbrechen</Link>
              </Button>

              <Button type="submit" disabled={isSaving}>
                <Save />
                {isSaving ? "Speichern …" : "Mannschaft erstellen"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </main>
  );
}

export default TeamCreatePage;
