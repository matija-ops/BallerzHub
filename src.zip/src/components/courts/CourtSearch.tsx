import { useState } from "react";
import type { FormEvent } from "react";
import { Search } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface CourtSearchProps {
  onSearch: (query: string) => Promise<void>;
  isSearching: boolean;
}

export function CourtSearch({ onSearch, isSearching }: CourtSearchProps) {
  const [query, setQuery] = useState("");

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const trimmedQuery = query.trim();

    if (!trimmedQuery) {
      return;
    }

    await onSearch(trimmedQuery);
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="flex h-14 w-[480px] items-center rounded-xl bg-white px-3 shadow-lg"
    >
      <Input
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        placeholder="Ort oder Stadt suchen ..."
        disabled={isSearching}
        className="h-full flex-1 border-0 bg-transparent px-2 text-base shadow-none focus-visible:ring-0"
      />

      <Button
        type="submit"
        size="icon"
        disabled={isSearching}
        aria-label="Ort suchen"
        className="h-10 w-10 shrink-0 rounded-xl"
      >
        <Search className="h-5 w-5" />
      </Button>
    </form>
  );
}
