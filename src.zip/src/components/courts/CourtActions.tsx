import { Heart } from "lucide-react";

import { CourtReportDialog } from "@/components/courts/CourtReportDialog";
import { Button } from "@/components/ui/button";

interface CourtActionsProps {
  isFavorite: boolean;
  isFavoriteLoading: boolean;
  onToggleFavorite: () => void;

  isReportSubmitting: boolean;
  reportError: string | null;
  onCreateReport: (
    category: string,
    description: string,
    images: File[]
  ) => Promise<boolean>;
}

export function CourtActions({
  isFavorite,
  isFavoriteLoading,
  onToggleFavorite,
  isReportSubmitting,
  reportError,
  onCreateReport,
}: CourtActionsProps) {
  return (
    <section
      aria-label="Court-Aktionen"
      className="flex flex-col gap-3 sm:flex-row"
    >
      <Button
        type="button"
        variant={isFavorite ? "default" : "outline"}
        disabled={isFavoriteLoading}
        onClick={onToggleFavorite}
        className="flex-1"
      >
        <Heart className={isFavorite ? "h-4 w-4 fill-current" : "h-4 w-4"} />

        {isFavorite ? "Favorisiert" : "Favorisieren"}
      </Button>

      <CourtReportDialog
        isSubmitting={isReportSubmitting}
        error={reportError}
        onSubmit={onCreateReport}
      />
    </section>
  );
}
