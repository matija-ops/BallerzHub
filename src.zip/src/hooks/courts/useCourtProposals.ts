import { useCallback, useState } from "react";

import { supabase } from "@/lib/supabase";
import type { TablesInsert } from "@/types/supabase.types";

export function useCourtProposals() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const createProposal = useCallback(
    async (
      name: string,
      latitude: number,
      longitude: number,
      type: string,
      hoopsCount: number,
      description: string
    ): Promise<boolean> => {
      if (isSubmitting) {
        return false;
      }

      setIsSubmitting(true);
      setError(null);

      try {
        const {
          data: { user },
        } = await supabase.auth.getUser();

        if (!user) {
          throw new Error(
            "Du musst eingeloggt sein, um einen Court vorzuschlagen."
          );
        }

        if (!name.trim()) {
          throw new Error("Bitte gib einen Namen für den Court ein.");
        }

        if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
          throw new Error("Bitte wähle einen gültigen Standort aus.");
        }

        if (!type.trim()) {
          throw new Error("Bitte wähle einen Court-Typ aus.");
        }

        if (!Number.isInteger(hoopsCount) || hoopsCount < 1) {
          throw new Error("Bitte gib eine gültige Anzahl an Körben ein.");
        }

        if (!description.trim()) {
          throw new Error("Bitte beschreibe den Court.");
        }

        const proposal: TablesInsert<"court_proposals"> = {
          user_id: user.id,
          name: name.trim(),
          latitude,
          longitude,
          type: type.trim(),
          hoops_count: hoopsCount,
          description: description.trim(),
          status: "pending",
        };

        const { error: insertError } = await supabase
          .from("court_proposals")
          .insert(proposal);

        if (insertError) {
          throw insertError;
        }

        return true;
      } catch (submitError) {
        console.error(
          "Court-Vorschlag konnte nicht erstellt werden:",
          submitError
        );

        setError(
          submitError instanceof Error
            ? submitError.message
            : "Der Court-Vorschlag konnte nicht erstellt werden."
        );

        return false;
      } finally {
        setIsSubmitting(false);
      }
    },
    [isSubmitting]
  );

  return {
    isSubmitting,
    error,
    createProposal,
  };
}
